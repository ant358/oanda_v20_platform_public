class Tokens():
    def __init__(self) -> None:
        self.account = '101-004-11644460-001'
        self.token = '5daf74fe4ba1ab34c75530cda81f39d3-8fbbd780c8e9fc999f4acd2423fabe39'
